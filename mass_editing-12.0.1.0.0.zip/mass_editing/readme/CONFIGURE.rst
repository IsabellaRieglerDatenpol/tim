
To configure this module, you need to:

* Go to *Settings / Mass Editing / Mass Editing* and configure the object and fields for Mass Editing.
