* Oihane Crucelaegui <oihanecrucelaegi@gmail.com>
* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>
* Jay Vora <jay.vora@serpentcs.com>
* Jairo Llopis <jairo.llopis@tecnativa.com>
* Juan Negrete <jnegrete@casasalce.com>
* Raul Martin <raul.martin@braintec-group.com>
* Aitor Bouzas <aitor.bouzas@adaptivecity.com>
