
This module provides the following features:

* You can add, update or remove the values of more than one records on the fly at the same time.

* You can configure mass editing for any Odoo model.

